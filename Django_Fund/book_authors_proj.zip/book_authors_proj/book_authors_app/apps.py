from django.apps import AppConfig


class BookAuthorsAppConfig(AppConfig):
    name = 'book_authors_app'
