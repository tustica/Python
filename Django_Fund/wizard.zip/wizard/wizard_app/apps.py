from django.apps import AppConfig


class WizardAppConfig(AppConfig):
    name = 'wizard_app'
